import { ArrowRight, BookOpen, TrendingUp, Brain, Star, Quote } from "lucide-react";
import { BookCard } from "@/components/BookCard";
import { SectionHeader } from "@/components/SectionHeader";
import { ExitIntentPopup } from "@/components/ExitIntentPopup";

import heroBg from "@/assets/hero-bg.jpg";
import bookPaiRico from "@/assets/book-pai-rico.jpg";
import bookMenteMilionaria from "@/assets/book-mente-milionaria.jpg";
import bookInvestidor from "@/assets/book-investidor.jpg";
import bookMentalidade from "@/assets/book-mentalidade.jpg";

export default function App() {
  return (
    <main className="min-h-screen overflow-x-hidden">
      {/* HERO */}
      <section className="relative isolate flex min-h-[92vh] items-center justify-center px-6 pb-24 pt-32">
        <div className="absolute inset-0 -z-10">
          <img src={heroBg} alt="" className="h-full w-full object-cover opacity-50" width={1920} height={1280} />
          <div className="absolute inset-0 bg-gradient-to-b from-background/60 via-background/80 to-background" />
        </div>

        <div className="mx-auto max-w-4xl text-center">
          <div className="mb-8 inline-flex items-center gap-2 rounded-full border border-gold/40 bg-card/60 px-4 py-2 backdrop-blur animate-fade-in">
            <Star className="h-3.5 w-3.5 fill-gold text-gold" />
            <span className="text-xs font-medium uppercase tracking-[0.25em] text-gold-soft">
              Curadoria de leitura premium
            </span>
          </div>

          <h1 className="font-display text-5xl font-bold leading-[1.05] text-foreground sm:text-6xl md:text-7xl lg:text-8xl animate-fade-up">
            Quer ficar <span className="shimmer-text">rico</span>?
            <br />
            Comece por <span className="text-gradient-gold">esses livros</span>
          </h1>

          <p className="mx-auto mt-8 max-w-2xl text-lg leading-relaxed text-muted-foreground sm:text-xl animate-fade-up" style={{ animationDelay: "150ms" }}>
            Os livros que mudaram a vida financeira de{" "}
            <span className="font-semibold text-foreground">milhares de pessoas</span>. Conhecimento que se transforma em liberdade.
          </p>

          <div className="mt-12 flex flex-col items-center justify-center gap-4 sm:flex-row animate-fade-up" style={{ animationDelay: "300ms" }}>
            <a href="#educacao" className="group inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-gold px-8 py-4 text-sm font-bold uppercase tracking-wider text-primary-foreground shadow-gold transition-smooth hover:scale-[1.02] hover:brightness-110">
              Ver recomendações
              <ArrowRight className="h-4 w-4 transition-smooth group-hover:translate-x-1" />
            </a>
            <a href="#mentalidade" className="inline-flex items-center justify-center gap-2 rounded-xl border border-border bg-card/40 px-8 py-4 text-sm font-semibold uppercase tracking-wider text-foreground backdrop-blur transition-smooth hover:border-gold/60 hover:bg-card">
              Mentalidade de rico
            </a>
          </div>

          <div className="mx-auto mt-16 grid max-w-2xl grid-cols-3 gap-4 border-t border-border pt-8 animate-fade-up" style={{ animationDelay: "450ms" }}>
            <Stat value="+40M" label="Leitores" />
            <Stat value="4.9★" label="Avaliação" />
            <Stat value="100%" label="Best-sellers" />
          </div>
        </div>
      </section>

      {/* EDUCAÇÃO FINANCEIRA */}
      <section id="educacao" className="relative px-6 py-28">
        <div className="mx-auto max-w-7xl">
          <SectionHeader
            eyebrow="Capítulo 01"
            title="Educação Financeira"
            description="Comece pela base. Estes livros ensinam o que a escola nunca te contou sobre dinheiro — e mudam para sempre como você enxerga sua renda."
          />
          <div className="mt-16 grid gap-8 sm:grid-cols-2 lg:gap-10">
            <BookCard cover={bookPaiRico} title="Pai Rico, Pai Pobre" author="Robert T. Kiyosaki" description="O livro de educação financeira mais vendido do mundo. Aprenda a fazer o dinheiro trabalhar para você e construa ativos que geram liberdade." link="https://s.shopee.com.br/5VRgKzWC6Z" badge="Mais vendido" />
            <BookCard cover={bookMenteMilionaria} title="Os Segredos da Mente Milionária" author="T. Harv Eker" description="Reprograme seu cérebro para a riqueza. Descubra os 17 padrões mentais que separam milionários de pessoas comuns." link="https://s.shopee.com.br/6px3vbD2f3" />
          </div>
        </div>
      </section>

      <Divider icon={TrendingUp} />

      {/* INVESTIMENTOS */}
      <section id="investimentos" className="relative px-6 py-28">
        <div className="mx-auto max-w-7xl">
          <SectionHeader eyebrow="Capítulo 02" title="Investimentos" description="O próximo passo: aprender a multiplicar. Os clássicos que formaram os maiores investidores do mundo, incluindo Warren Buffett." />
          <div className="mt-16 grid gap-8 sm:grid-cols-2 lg:gap-10">
            <BookCard cover={bookInvestidor} title="O Investidor Inteligente" author="Benjamin Graham" description="A bíblia dos investimentos. O livro que ensinou Warren Buffett a investir com inteligência, paciência e segurança real." link="https://s.shopee.com.br/70GU7zjaMP" badge="Clássico atemporal" />
            <div className="relative flex flex-col justify-center overflow-hidden rounded-2xl border border-gold/30 bg-card p-10 text-center shadow-card">
              <div className="absolute inset-0 opacity-60" style={{ background: "var(--gradient-radial-gold)" }} />
              <div className="relative">
                <Quote className="mx-auto h-10 w-10 text-gold/70" />
                <blockquote className="mt-6 font-display text-2xl leading-snug text-foreground sm:text-3xl">
                  "O mercado de ações foi projetado para transferir dinheiro do impaciente para o paciente."
                </blockquote>
                <p className="mt-6 text-sm uppercase tracking-[0.25em] text-gold-soft">— Warren Buffett</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Divider icon={Brain} />

      {/* MENTALIDADE */}
      <section id="mentalidade" className="relative px-6 py-28">
        <div className="mx-auto max-w-7xl">
          <SectionHeader eyebrow="Capítulo 03" title="Mentalidade de Rico" description="Antes do dinheiro vem a mente. Sem a mentalidade certa, nenhuma fortuna se mantém. Esta é a chave que falta para quase todos." />
          <div className="mt-16 grid gap-8 sm:grid-cols-2 lg:gap-10">
            <BookCard cover={bookMentalidade} title="A Mente Vencedora" author="John C. Maxwell" description="Transforme pensamentos limitantes em hábitos vencedores. O passo a passo para construir a mentalidade que atrai abundância." link="https://s.shopee.com.br/7ppb7dUmoB" badge="Transformação" />
            <div className="relative flex flex-col justify-center gap-6 overflow-hidden rounded-2xl border border-border bg-gradient-to-br from-card to-background p-10 shadow-card">
              <div className="flex h-14 w-14 items-center justify-center rounded-full bg-gold/15 text-gold">
                <BookOpen className="h-7 w-7" />
              </div>
              <h3 className="font-display text-3xl font-bold text-foreground sm:text-4xl">
                Por que <span className="text-gradient-gold">ler muda tudo</span>?
              </h3>
              <p className="text-base leading-relaxed text-muted-foreground">
                Os mais ricos do mundo leem em média <strong className="text-foreground">52 livros por ano</strong>. Não é coincidência — é o atalho mais barato para décadas de experiência condensadas em poucas horas.
              </p>
              <a href="#educacao" className="inline-flex w-fit items-center gap-2 text-sm font-semibold uppercase tracking-wider text-gold transition-smooth hover:gap-3">
                Voltar ao topo da lista
                <ArrowRight className="h-4 w-4" />
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* CTA FINAL */}
      <section className="px-6 py-28">
        <div className="relative mx-auto max-w-4xl overflow-hidden rounded-3xl border border-gold/30 bg-card p-12 text-center shadow-elegant sm:p-16">
          <div className="absolute inset-0 opacity-70" style={{ background: "var(--gradient-radial-gold)" }} />
          <div className="relative">
            <p className="text-xs font-semibold uppercase tracking-[0.3em] text-gold">Comece hoje</p>
            <h2 className="mt-4 font-display text-4xl font-bold leading-tight text-foreground sm:text-5xl">
              A diferença entre quem fica rico e quem fica preso<br />
              está em <span className="text-gradient-gold">uma decisão</span>.
            </h2>
            <p className="mx-auto mt-6 max-w-xl text-base leading-relaxed text-muted-foreground sm:text-lg">
              Escolha o primeiro livro. Em uma semana, sua forma de pensar sobre dinheiro nunca mais será a mesma.
            </p>
            <a href="#educacao" className="mt-10 inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-gold px-10 py-4 text-sm font-bold uppercase tracking-wider text-primary-foreground shadow-gold transition-smooth hover:scale-[1.02] hover:brightness-110">
              Escolher meu primeiro livro
              <ArrowRight className="h-4 w-4" />
            </a>
          </div>
        </div>
      </section>

      <footer className="border-t border-border px-6 py-10">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 text-center text-xs text-muted-foreground sm:flex-row sm:text-left">
          <p className="font-display text-base text-foreground">
            Riqueza<span className="text-gold">.</span>
          </p>
          <p className="max-w-md leading-relaxed">
            Este site contém links de afiliado. Podemos receber comissões por compras realizadas, sem custo adicional para você.
          </p>
          <p>© {new Date().getFullYear()} — Todos os direitos reservados</p>
        </div>
      </footer>

      <ExitIntentPopup />
    </main>
  );
}

function Stat({ value, label }: { value: string; label: string }) {
  return (
    <div>
      <p className="font-display text-3xl font-bold text-gradient-gold sm:text-4xl">{value}</p>
      <p className="mt-1 text-xs uppercase tracking-[0.2em] text-muted-foreground">{label}</p>
    </div>
  );
}

function Divider({ icon: Icon }: { icon: React.ComponentType<{ className?: string }> }) {
  return (
    <div className="mx-auto flex max-w-7xl items-center gap-6 px-6">
      <div className="gold-divider flex-1" />
      <div className="flex h-12 w-12 items-center justify-center rounded-full border border-gold/30 bg-card text-gold">
        <Icon className="h-5 w-5" />
      </div>
      <div className="gold-divider flex-1" />
    </div>
  );
}
