import { useEffect, useState } from "react";
import { X, Sparkles, ArrowRight } from "lucide-react";

const STORAGE_KEY = "rich-books-popup-shown";

export function ExitIntentPopup() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (sessionStorage.getItem(STORAGE_KEY)) return;

    const timer = window.setTimeout(() => {
      setOpen(true);
      sessionStorage.setItem(STORAGE_KEY, "1");
    }, 12000);

    const onLeave = (e: MouseEvent) => {
      if (e.clientY <= 0 && !sessionStorage.getItem(STORAGE_KEY)) {
        setOpen(true);
        sessionStorage.setItem(STORAGE_KEY, "1");
      }
    };
    document.addEventListener("mouseleave", onLeave);

    return () => {
      window.clearTimeout(timer);
      document.removeEventListener("mouseleave", onLeave);
    };
  }, []);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 px-4 backdrop-blur-sm animate-fade-in"
      onClick={() => setOpen(false)}
    >
      <div
        className="relative w-full max-w-lg overflow-hidden rounded-3xl border border-gold/30 bg-card shadow-elegant animate-fade-up"
        onClick={(e) => e.stopPropagation()}
      >
        <div
          className="absolute inset-0 opacity-40"
          style={{ background: "var(--gradient-radial-gold)" }}
        />

        <button
          aria-label="Fechar"
          onClick={() => setOpen(false)}
          className="absolute right-4 top-4 z-10 rounded-full p-2 text-muted-foreground transition-smooth hover:bg-muted hover:text-foreground"
        >
          <X className="h-5 w-5" />
        </button>

        <div className="relative px-8 py-12 text-center sm:px-12">
          <div className="mx-auto mb-6 flex h-14 w-14 items-center justify-center rounded-full bg-gold/15 text-gold animate-glow-pulse">
            <Sparkles className="h-7 w-7" />
          </div>

          <p className="text-xs font-semibold uppercase tracking-[0.3em] text-gold">
            Espere antes de sair
          </p>
          <h3 className="mt-4 font-display text-3xl font-bold leading-tight text-foreground sm:text-4xl">
            O <span className="text-gradient-gold">primeiro livro</span> pode mudar tudo
          </h3>
          <p className="mt-4 text-base leading-relaxed text-muted-foreground">
            Mais de 40 milhões de pessoas começaram sua jornada financeira com{" "}
            <span className="font-semibold text-foreground">Pai Rico, Pai Pobre</span>. Garanta o seu agora com desconto.
          </p>

          <a
            href="https://s.shopee.com.br/5VRgKzWC6Z"
            target="_blank"
            rel="noopener noreferrer sponsored"
            className="mt-8 inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-gold px-8 py-4 text-sm font-bold uppercase tracking-wider text-primary-foreground shadow-gold transition-smooth hover:scale-[1.02] hover:brightness-110"
            onClick={() => setOpen(false)}
          >
            Quero começar agora
            <ArrowRight className="h-4 w-4" />
          </a>

          <button
            onClick={() => setOpen(false)}
            className="mt-4 block w-full text-xs uppercase tracking-wider text-muted-foreground transition-smooth hover:text-foreground"
          >
            Não, prefiro continuar sem
          </button>
        </div>
      </div>
    </div>
  );
}
