import { ArrowUpRight } from "lucide-react";

interface BookCardProps {
  cover: string;
  title: string;
  author: string;
  description: string;
  link: string;
  badge?: string;
}

export function BookCard({ cover, title, author, description, link, badge }: BookCardProps) {
  return (
    <article className="group relative flex flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-card transition-smooth hover:-translate-y-1 hover:shadow-elegant hover:border-gold/40">
      <div className="relative overflow-hidden bg-background">
        <div className="absolute inset-0 bg-gradient-radial-gold opacity-0 transition-smooth group-hover:opacity-100" style={{ background: "var(--gradient-radial-gold)" }} />
        <img
          src={cover}
          alt={`Capa do livro ${title}`}
          loading="lazy"
          width={768}
          height={1024}
          className="aspect-[3/4] w-full object-cover transition-smooth group-hover:scale-105"
        />
        {badge && (
          <span className="absolute left-4 top-4 rounded-full bg-gold/95 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-primary-foreground shadow-gold">
            {badge}
          </span>
        )}
      </div>

      <div className="flex flex-1 flex-col gap-4 p-6">
        <div>
          <p className="text-xs uppercase tracking-[0.2em] text-gold-soft/80">{author}</p>
          <h3 className="mt-2 font-display text-2xl font-semibold text-foreground">{title}</h3>
        </div>
        <p className="text-sm leading-relaxed text-muted-foreground">{description}</p>

        <a
          href={link}
          target="_blank"
          rel="noopener noreferrer sponsored"
          className="mt-auto inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-gold px-6 py-3.5 text-sm font-semibold uppercase tracking-wider text-primary-foreground shadow-gold transition-smooth hover:scale-[1.02] hover:brightness-110 active:scale-[0.98]"
        >
          Comprar agora
          <ArrowUpRight className="h-4 w-4" />
        </a>
      </div>
    </article>
  );
}
